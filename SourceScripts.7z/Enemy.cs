﻿// Enemy.cs
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Rigidbody2D))]
public class Enemy : MonoBehaviour
{
    [Header("Stats")]
    public float moveSpeed = 3f;
    public float attackRange = 1.5f;
    public float attackCooldown = 1.2f;
    public float sightRange = 10f;
    public float health = 50f;
    public float separationRadius = 1.5f;
    public Slider healthSlider;

    [Header("Combat")]
    public float baseDamage = 8f;
    public float critChance = 0.15f;
    public float critMultiplier = 1.75f;

    public enum BehaviorType { Charger, Orbit }
    public BehaviorType behaviorType = BehaviorType.Charger;
    private float orbitAngle;
    public float orbitSpeed = 45f;

    private Transform player;
    private PlayerController playerController;
    private Rigidbody2D rb;
    private Animator animator;
    private SpriteRenderer spriteRenderer;

    private bool isDead = false;
    private bool isAttacking = false;
    private Vector2 moveDirection;
    private float attackTimer = 0f;
    private float idleCooldown = 0f;

    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player")?.transform;
        playerController = player?.GetComponent<PlayerController>();
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    void Update()
    {
        if (isDead || player == null) return;

        float distance = Vector2.Distance(transform.position, player.position);

        if (distance < sightRange && !IsIdle())
        {
            Vector2 direction = behaviorType == BehaviorType.Orbit ? GetOrbitDirection() : (player.position - transform.position).normalized;
            Vector2 separation = ComputeSeparation();
            moveDirection = (direction + separation).normalized;

            if (distance <= attackRange && attackTimer <= 0f)
            {
                StartCoroutine(PerformAttack());
            }
        }
        else
        {
            moveDirection = Vector2.zero;
        }

        if (attackTimer > 0f)
            attackTimer -= Time.deltaTime;

        if (idleCooldown > 0f)
            idleCooldown -= Time.deltaTime;
        else if (Random.value < 0.005f)
            idleCooldown = Random.Range(1f, 2f);

        UpdateHealthBar();
        animator.SetBool("isMoving", moveDirection != Vector2.zero);
    }

    void FixedUpdate()
    {
        if (isDead || moveDirection == Vector2.zero || IsIdle()) return;

        Vector2 moveStep = moveSpeed * Time.fixedDeltaTime * moveDirection;
        rb.MovePosition(rb.position + moveStep);

        if (moveDirection.x != 0)
            spriteRenderer.flipX = moveDirection.x < 0;
    }

    bool IsIdle() => idleCooldown > 0f;

    IEnumerator PerformAttack()
    {
        isAttacking = true;
        attackTimer = attackCooldown;
        animator.SetTrigger("Attack");

        yield return new WaitForSeconds(0.3f);

        if (Vector2.Distance(transform.position, player.position) <= attackRange)
        {
            float damage = baseDamage * (Random.value < critChance ? critMultiplier : 1f);
            playerController?.TakeDamage(damage);
        }

        yield return new WaitForSeconds(attackCooldown - 0.3f);
        isAttacking = false;
    }

    Vector2 ComputeSeparation()
    {
        Vector2 force = Vector2.zero;
        Collider2D[] colliders = Physics2D.OverlapCircleAll(transform.position, separationRadius);

        foreach (var col in colliders)
        {
            if (col != null && col.gameObject != this.gameObject && col.CompareTag("Enemy"))
            {
                Vector2 away = (Vector2)(transform.position - col.transform.position);
                force += away.normalized / Mathf.Max(away.magnitude, 0.01f);
            }
        }

        return force * 0.5f;
    }

    Vector2 GetOrbitDirection()
    {
        orbitAngle += orbitSpeed * Time.deltaTime;
        float rad = orbitAngle * Mathf.Deg2Rad;
        Vector2 offset = new Vector2(Mathf.Cos(rad), Mathf.Sin(rad)) * (attackRange + 0.5f);
        Vector2 targetPos = (Vector2)player.position + offset;
        return (targetPos - (Vector2)transform.position).normalized;
    }

    public void TakeDamage(float amount)
    {
        if (isDead) return;
        health -= amount;
        if (health <= 0)
            Die();
    }

    void Die()
    {
        if (isDead) return;

        isDead = true;
        moveDirection = Vector2.zero;
        animator.SetTrigger("Defeated");
        Destroy(gameObject, 1f);

        // 🎁 Récompense joueur
        if (playerController != null)
        {
            if (playerController.TryGetComponent(out LevelSystem level))
            {
                level.AddExperience(50); // Exemple : 50 XP

                // 🪄 Débloque le sort AOE au niveau 3
                if (level.currentLevel >= 3 && playerController.TryGetComponent(out PlayerSpells spells))
                {
                    spells.UnlockAOESpell();
                }
            }
        }
    }


    void UpdateHealthBar()
    {
        if (healthSlider != null)
            healthSlider.value = Mathf.Clamp01(health / 50f);
    }
}
