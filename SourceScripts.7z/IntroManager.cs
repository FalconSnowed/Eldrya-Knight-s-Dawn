﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections;

public class IntroManager : MonoBehaviour
{
    [Header("UI Elements")]
    public CanvasGroup introCanvasGroup;
    public TextMeshProUGUI introText;
    public string[] introLines;
    public float textDisplayTime = 4f;
    public float fadeDuration = 1.5f;
    public KeyCode skipKey = KeyCode.Space;

    [Header("After Intro")]
    public GameObject gameUI;
    public GameObject player;
    public Camera introCamera;
    // public Camera mainCamera;

    [Header("Quest")]
    public GameObject mainQuestTrigger;

    private bool isSkipping = false;

    void Start()
    {
        if (PlayerPrefs.GetInt("IntroPlayed", 0) == 1)
        {
            // L’intro a déjà été jouée, on la désactive
            introCanvasGroup.alpha = 0;
            gameUI.SetActive(true);
            introCamera.enabled = false;
            introCamera.gameObject.SetActive(false);

            // 🔁 Active la caméra fixe si elle existe
            if (CameraFixedZoneController.Instance != null && CameraFixedZoneController.Instance.mainCamera != null)
            {
                CameraFixedZoneController.Instance.mainCamera.gameObject.SetActive(true);
            }


            if (player.TryGetComponent(out PlayerController controller))
                controller.canMove = true;

            if (mainQuestTrigger != null)
                mainQuestTrigger.SetActive(true);

            Destroy(this); // Supprime le script pour éviter tout déclenchement
            return;
        }


        // Sinon, on lance l’intro normalement
        introCanvasGroup.alpha = 0;
        gameUI.SetActive(false);
        PlayerController pc = player.GetComponent<PlayerController>();
        if (pc != null)
            pc.canMove = false;

        introCamera.enabled = true;
        StartCoroutine(PlayIntro());
    }


    IEnumerator PlayIntro()
    {
        foreach (string line in introLines)
        {
            yield return StartCoroutine(FadeInText(line));
            float timer = 0f;
            while (timer < textDisplayTime && !isSkipping)
            {
                if (Input.GetKeyDown(skipKey))
                {
                    isSkipping = true;
                    break;
                }
                timer += Time.deltaTime;
                yield return null;
            }
            yield return StartCoroutine(FadeOutText());
            if (isSkipping) break;
        }

        EndIntro();
    }

    IEnumerator FadeInText(string line)
    {
        introText.text = line;
        float t = 0f;
        while (t < fadeDuration)
        {
            introCanvasGroup.alpha = t / fadeDuration;
            t += Time.deltaTime;
            yield return null;
        }
        introCanvasGroup.alpha = 1;
    }

    IEnumerator FadeOutText()
    {
        float t = 0f;
        while (t < fadeDuration)
        {
            introCanvasGroup.alpha = 1 - (t / fadeDuration);
            t += Time.deltaTime;
            yield return null;
        }
        introCanvasGroup.alpha = 0;
    }
    void EndIntro()
    {
        gameUI.SetActive(true);

        if (player.TryGetComponent(out PlayerController controller))
            controller.canMove = true;

        if (mainQuestTrigger != null)
            mainQuestTrigger.SetActive(true);

        PlayerPrefs.SetInt("IntroPlayed", 1);

        // Sécurité : réactive la caméra fixe
        if (CameraFixedZoneController.Instance != null && CameraFixedZoneController.Instance.mainCamera != null)
        {
            CameraFixedZoneController.Instance.mainCamera.gameObject.SetActive(true);
        }
    }

}