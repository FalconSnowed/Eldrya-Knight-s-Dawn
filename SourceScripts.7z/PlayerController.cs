﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;
using TMPro;

public class PlayerController : MonoBehaviour
{
    public bool isFacingRight = true;
    public Camera playerCamera;
    private AudioListener audioListener;
    private PlayerInput playerInput;
    private PlayerSpells spells;
    [SerializeField] private TMP_Text usernameText;
    public string playerName = "Hero";
    public string className = "Guerrier";

    [Header("Refs")]

    private float lastHitTime = -999f;
    public float hitCooldown = 1.0f;

    // Statistiques RPG
    public int attack = 12;
    public int defense = 5;
    public int maxHealth = 100;
    public int currentHealth = 75;

    // Portrait (si image assignée)
    public Texture2D portrait;

    public float moveSpeed = 1f;
    public float collisionOffset = 0.05f;
    public ContactFilter2D movementFilter;
    public SwordAttack swordAttack;


    public float enduranceRegenRate = 5f;
    public float dashSpeedMultiplier = 2f;
    public float maxMana = 100f;
    public float currentMana;
    public float dashEnduranceCost = 20f;
    public float dashDistance = 5f;
    public float maxEndurance = 100f;
    public float currentEndurance;
    public float dashDuration = 0.5f;
    private bool isDashing = false;

    public Slider healthSlider;
    public Slider manaSlider;
    public Slider enduranceSlider;

    Vector2 movementInput;
    SpriteRenderer spriteRenderer;
    Rigidbody2D rb;
    Animator animator;
    readonly List<RaycastHit2D> castCollisions = new();

    public bool canMove = true;
    public string KnightHome;
    public new Camera camera;

    void Start()
    {
        currentHealth = maxHealth;
        currentMana = maxMana;
        currentEndurance = maxEndurance;

        UpdateHealthBar();
        UpdateManaBar();
        UpdateEnduranceBar();
        spells = GetComponent<PlayerSpells>();
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        audioListener = GetComponent<AudioListener>();
        playerInput = GetComponent<PlayerInput>();

        RegenerateEndurance();
    }

    void OnDash()
    {
        animator.SetTrigger("DashTrigger");
        StartCoroutine(DashFunction());
    }

    IEnumerator DashFunction()
    {
        UseEndurance(dashEnduranceCost);

        isDashing = true;

        Vector2 initialPosition = rb.position;
        Vector2 dashDestination = initialPosition + movementInput.normalized * dashDistance;

        UpdateEnduranceBar();

        float elapsed = 0f;
        LayerMask dashLayerMask = LayerMask.GetMask("Default");
        while (elapsed < dashDuration)
        {
            Vector2 projectedPosition = Vector2.Lerp(initialPosition, dashDestination, elapsed / dashDuration);
            RaycastHit2D hit = Physics2D.Raycast(rb.position, (projectedPosition - rb.position).normalized, Vector2.Distance(rb.position, projectedPosition), dashLayerMask);

            if (hit.collider == null)
            {
                rb.MovePosition(projectedPosition);
                rb.velocity = dashSpeedMultiplier * moveSpeed * rb.velocity.normalized;
            }
            else
            {
                break;
            }

            elapsed += Time.deltaTime;
            yield return null;
        }

        isDashing = false;
    }

    void FixedUpdate()
    {
        if (canMove)
        {
            MovePlayer();
        }
    }

    void Update()
    {
        RegenerateEndurance();
        CheckDeath();

        if (GameManager.Instance != null && GameManager.Instance.IsInventoryOpen)
        {
            if (playerInput != null && playerInput.enabled)
                playerInput.enabled = false;
            return;
        }
        if (Input.GetKeyDown(KeyCode.R))
        {
            spells?.CastAOE();
        }
        if (playerInput != null && !playerInput.enabled)
            playerInput.enabled = true;
    }


    private void CheckDeath()
    {
        if (currentHealth <= 0)
        {
            HandleDeath();
        }
    }


    private bool isDead = false;

    private void HandleDeath()
    {
        if (isDead) return;

        isDead = true;
        animator.SetTrigger("Death");
        StartCoroutine(RespawnTimer());
    }

    private IEnumerator RespawnTimer()
    {
        float respawnTime = 5f;

        canMove = false;
        playerInput.enabled = false;

        Debug.Log("Défaite ! Réapparition dans 5 secondes...");
        yield return new WaitForSeconds(respawnTime);

        // Réapparition
        // 📍 Réapparition au point défini
        Transform spawnPoint = GameObject.Find("PlayerSpawnPoint")?.transform;
        if (spawnPoint != null)
        {
            transform.position = spawnPoint.position;

            // 🧭 Mise à jour de la caméra
            Transform camPoint = GameObject.Find("FixedCam_SpawnZone")?.transform;
            if (CameraFixedZoneController.Instance != null && camPoint != null)
                CameraFixedZoneController.Instance.MoveCameraTo(camPoint);
        }
        else
        {
            transform.position = Vector3.zero;
            Debug.LogWarning("⚠️ Aucun point de spawn trouvé !");
        }

        currentHealth = maxHealth;
        UpdateHealthBar();

        canMove = true;
        playerInput.enabled = true;
        isDead = false;

        // 🔄 Déplacement caméra vers le point de respawn
        if (CameraFixedZoneController.Instance != null)
        {
            Transform respawnCamPoint = GameObject.Find("FixedCam_SpawnZone")?.transform;
            if (respawnCamPoint != null)
                CameraFixedZoneController.Instance.MoveCameraTo(respawnCamPoint);
        }
    }


    void MovePlayer()
    {
        if (movementInput != Vector2.zero)
        {
            bool success = TryMove(movementInput);

            if (!success)
            {
                success = TryMove(new Vector2(movementInput.x, 0));
            }

            if (!success)
            {
                success = TryMove(new Vector2(0, movementInput.y));
            }

            animator.SetBool("isMoving", success);
        }
        else
        {
            animator.SetBool("isMoving", false);
        }

        if (movementInput.x < 0)
        {
            spriteRenderer.flipX = true;
        }
        else if (movementInput.x > 0)
        {
            spriteRenderer.flipX = false;
        }
    }

    private bool TryMove(Vector2 direction)
    {
        if (direction != Vector2.zero)
        {
            Vector2 newPosition = rb.position + moveSpeed * Time.fixedDeltaTime * direction;
            int count = rb.Cast(direction, movementFilter, castCollisions, moveSpeed * Time.fixedDeltaTime + collisionOffset);

            if (count == 0)
            {
                transform.position = newPosition;
                return true;
            }
            return false;
        }
        else
        {
            return false;
        }
    }

    void OnMove(InputValue value)
    {
        movementInput = value.Get<Vector2>();
    }

    void OnFire()
    {
        animator.SetTrigger("swordAttack");
        SwordAttack();
    }

    void RegenerateEndurance()
    {
        if (!isDashing)
        {
            currentEndurance += enduranceRegenRate * Time.deltaTime;
            currentEndurance = Mathf.Min(currentEndurance, maxEndurance);
            UpdateEnduranceBar();
        }
    }

    public void UpdateHealthBar()
    {
        float normalizedHealth = (float)currentHealth / maxHealth;
        healthSlider.value = normalizedHealth;

        healthSlider.maxValue = maxHealth;
        healthSlider.value = currentHealth;

    }

    public void UpdateManaBar()
    {
        float normalizedMana = currentMana / maxMana;
        manaSlider.value = normalizedMana;
    }

    public void UpdateEnduranceBar()
    {
        float normalizedEndurance = currentEndurance / maxEndurance;
        enduranceSlider.value = normalizedEndurance;
    }

    public void TakeDamage(float damage)
    {
        if (Time.time - lastHitTime < hitCooldown) return;

        lastHitTime = Time.time;

        int mitigated = Mathf.Max(Mathf.RoundToInt(damage - defense), 1);
        currentHealth -= mitigated;
        currentHealth = Mathf.Max(currentHealth, 0);
        UpdateHealthBar();

        Debug.Log($"Dégâts: {damage}, atténués: {mitigated}, Vie restante: {currentHealth}");
        StartCoroutine(FlashRed());

    }

    IEnumerator FlashRed()
    {
        Color originalColor = spriteRenderer.color;
        spriteRenderer.color = Color.red;
        yield return new WaitForSeconds(0.1f);
        spriteRenderer.color = originalColor;
    }

    void UseMana(float manaCost)
    {
        currentMana -= manaCost;
        currentMana = Mathf.Max(currentMana, 0f);
        UpdateManaBar();
    }

    void UseEndurance(float enduranceCost)
    {
        currentEndurance -= enduranceCost;
        currentEndurance = Mathf.Max(currentEndurance, 0f);
        UpdateEnduranceBar();
    }

    public void SwordAttack()
    {
        swordAttack.Attack(spriteRenderer.flipX);
    }

    public void EndSwordAttack()
    {
        swordAttack.StopAttack();
    }
}
